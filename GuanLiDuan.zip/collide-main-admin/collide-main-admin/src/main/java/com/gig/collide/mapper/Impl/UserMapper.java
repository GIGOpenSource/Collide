package com.gig.collide.mapper.Impl;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gig.collide.domain.user.User;


public interface UserMapper extends BaseMapper<User> {
}