package com.gig.collide.mapper.Impl;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gig.collide.domain.admin.AdminOperationLog;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AdminOperationLogMapper extends BaseMapper<AdminOperationLog> {

}
