package com.gig.collide.service.Impl;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gig.collide.domain.user.User;

/**
 * 用户服务接口
 */
public interface UserService extends IService<User> {

}