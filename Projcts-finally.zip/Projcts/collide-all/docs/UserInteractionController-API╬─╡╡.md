# 用户互动查询API文档

## 概述

用户互动查询API整合了用户的点赞和评论数据查询功能，提供统一的接口来获取用户的各种互动记录。

## 基础信息

- **基础路径**: `/api/v1/user-interactions`
- **数据格式**: JSON
- **字符编码**: UTF-8

## 核心接口

### 1. 通用查询接口

#### 1.1 POST方式查询
```
POST /api/v1/user-interactions/list
```

**请求体**:
```json
{
  "userId": 123,
  "interactionType": "ALL",
  "likeType": "CONTENT",
  "commentType": "CONTENT",
  "direction": "ALL",
  "orderBy": "createTime",
  "orderDirection": "DESC",
  "currentPage": 1,
  "pageSize": 20
}
```

#### 1.2 GET方式查询
```
GET /api/v1/user-interactions/list?userId=123&interactionType=ALL&likeType=CONTENT&commentType=CONTENT&direction=ALL&orderBy=createTime&orderDirection=DESC&currentPage=1&pageSize=20
```

**参数说明**:
- `userId` (必填): 用户ID
- `interactionType` (可选): 互动类型 - ALL/LIKES/COMMENTS
- `likeType` (可选): 点赞类型 - CONTENT/COMMENT
- `commentType` (可选): 评论类型 - CONTENT/DYNAMIC
- `direction` (可选): 查询方向 - ALL/GIVE/RECEIVE
- `orderBy` (可选): 排序字段 - createTime/updateTime
- `orderDirection` (可选): 排序方向 - ASC/DESC
- `currentPage` (可选): 当前页码，默认1
- `pageSize` (可选): 页面大小，默认20

### 2. 专用查询接口

#### 2.1 查询我点赞的内容
```
GET /api/v1/user-interactions/my-liked-contents?userId=123&currentPage=1&pageSize=20
```

#### 2.2 查询我点赞的评论
```
GET /api/v1/user-interactions/my-liked-comments?userId=123&currentPage=1&pageSize=20
```

#### 2.3 查询我发出的评论
```
GET /api/v1/user-interactions/my-comments?userId=123&commentType=CONTENT&currentPage=1&pageSize=20
```

#### 2.4 查询我收到的评论
```
GET /api/v1/user-interactions/comments-to-me?userId=123&currentPage=1&pageSize=20
```

#### 2.5 查询我收到的点赞
```
GET /api/v1/user-interactions/likes-to-my-comments?userId=123&currentPage=1&pageSize=20
```


## 响应格式

### 成功响应
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "records": [
      {
        "id": 1,
        "interactionType": "LIKE",
        "subType": "CONTENT",
        "targetId": 100,
        "targetTitle": "示例内容标题",
        "targetAuthorId": 456,
        "targetAuthorNickname": "内容作者昵称",
        "targetAuthorAvatar": "内容作者头像URL",
        "isFollowingAuthor": true,
        "contentLikeCount": 25,
        "isLike": true,
        "contentCoverUrl": ["https://example.com/cover1.jpg", "https://example.com/cover2.jpg"],
        "contentDescription": "这是一个示例内容的描述",
        "userId": 123,
        "userNickname": "用户昵称",
        "userAvatar": "用户头像URL",
        "commentContent": null,
        "parentCommentId": null,
        "replyToUserId": null,
        "replyToUserNickname": null,
        "likeCount": null,
        "replyCount": null,
        "status": "active",
        "createTime": "2024-01-16 10:30:00",
        "updateTime": "2024-01-16 10:30:00"
      }
    ],
    "total": 1,
    "currentPage": 1,
    "pageSize": 20,
    "totalPages": 1
  }
}
```

### 错误响应
```json
{
  "code": 400,
  "message": "用户ID不能为空",
  "data": null
}
```

## 字段说明

### UserInteractionResponse 字段

| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | Long | 互动ID |
| interactionType | String | 互动类型：LIKE/COMMENT |
| subType | String | 互动子类型：CONTENT/COMMENT/DYNAMIC |
| targetId | Long | 目标对象ID |
| targetTitle | String | 目标对象标题 |
| targetAuthorId | Long | 目标对象作者ID |
| targetAuthorNickname | String | 目标对象作者昵称 |
| targetAuthorAvatar | String | 目标对象作者头像 |
| isFollowingAuthor | Boolean | 是否关注该内容作者 |
| contentLikeCount | Long | 该内容被点赞总数量 |
| isLike | Boolean | 是否点赞该内容 |
| contentCoverUrl | List<String> | 内容封面图片URL列表 |
| contentDescription | String | 内容描述 |
| userId | Long | 互动用户ID |
| userNickname | String | 互动用户昵称 |
| userAvatar | String | 互动用户头像 |
| commentContent | String | 评论内容（仅评论类型有值） |
| parentCommentId | Long | 父评论ID（仅评论类型有值） |
| replyToUserId | Long | 回复目标用户ID（仅评论类型有值） |
| replyToUserNickname | String | 回复目标用户昵称（仅评论类型有值） |
| likeCount | Integer | 点赞数（仅评论类型有值） |
| replyCount | Integer | 回复数（仅评论类型有值） |
| status | String | 状态 |
| createTime | String | 创建时间 |
| updateTime | String | 更新时间 |

## 业务逻辑说明

### 1. 查询方向说明
- **GIVE**: 我发出的（我点赞的内容/我发出的评论）
- **RECEIVE**: 我收到的（我收到的点赞/我收到的评论）
- **ALL**: 所有互动

### 2. 互动类型说明
- **LIKE**: 点赞类型
  - CONTENT: 内容点赞
  - COMMENT: 评论点赞
- **COMMENT**: 评论类型
  - CONTENT: 内容评论
  - DYNAMIC: 动态评论

### 3. 数据整合逻辑
1. 根据 `interactionType` 和 `direction` 参数分别查询点赞和评论数据
2. 将查询结果转换为统一的 `UserInteractionResponse` 格式
3. 对合并后的数据进行排序（按创建时间或更新时间）
4. 对排序后的数据进行分页处理

### 4. 性能优化
- 单次查询限制最大1000条记录，避免性能问题
- 支持分页查询，减少内存占用
- 使用索引优化查询性能

## 错误码说明

| 错误码 | 说明 |
|--------|------|
| 200 | 成功 |
| 400 | 参数错误 |
| 500 | 服务器内部错误 |

## 使用示例

### 示例1：查询用户点赞的内容
```bash
curl -X GET "http://localhost:8080/api/v1/user-interactions/my-liked-contents?userId=123&currentPage=1&pageSize=20"
```

### 示例2：使用POST方式复杂查询
```bash
curl -X POST "http://localhost:8080/api/v1/user-interactions/list" \
  -H "Content-Type: application/json" \
  -d '{
    "userId": 123,
    "interactionType": "LIKES",
    "likeType": "CONTENT",
    "direction": "GIVE",
    "orderBy": "createTime",
    "orderDirection": "DESC",
    "currentPage": 1,
    "pageSize": 20
  }'
```

## 注意事项

1. **目标作者信息**: 现在会返回内容作者的昵称和头像信息
2. **关注状态**: 会返回当前用户是否关注内容作者的状态
3. **内容点赞数量**: 会返回该内容被点赞的总数量
4. **数据限制**: 单次查询最多返回1000条记录，避免性能问题
5. **排序规则**: 默认按创建时间降序排列
6. **分页参数**: 页码从1开始，页面大小建议不超过100
7. **状态过滤**: 点赞数据只查询active状态，评论数据只查询NORMAL状态
8. **性能优化**: 使用批量查询优化数据库访问，减少N+1查询问题

## 版本信息

- **版本**: 1.0.0
- **创建时间**: 2024-01-16
- **作者**: GIG Team
