# AuthController API 文档

## 概述

认证控制器提供用户登录、登出、token校验等功能。

## 接口列表

### 1. 用户登录

- **URL**: `/api/v1/auth/login`
- **方法**: `POST`
- **描述**: 用户登录并返回认证token

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| username | String | 是 | 用户名 |
| password | String | 是 | 密码 |

#### 响应示例

```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "tokenName": "Authorization",
    "expiresIn": 2592000,
    "userInfo": {
      "id": 1,
      "username": "testuser",
      "nickname": "测试用户",
      "email": "test@example.com",
      "phone": "13800138000",
      "avatar": "https://example.com/avatar.jpg",
      "status": "active",
      "isVip": false,
      "lastLoginTime": "2024-01-27 10:30:00",
      "loginCount": 5,
      "createTime": "2024-01-01 00:00:00",
      "followingCount": 10,
      "followersCount": 25,
      "likeCount": 150
    }
  },
  "success": true,
  "timestamp": 1703123456789
}
```

### 2. 用户登出

- **URL**: `/api/v1/auth/logout`
- **方法**: `POST`
- **描述**: 用户登出并清除token

#### 响应示例

```json
{
  "code": 200,
  "message": "操作成功",
  "data": "登出成功",
  "success": true,
  "timestamp": 1703123456789
}
```

### 3. 获取用户信息（权限已放开）

- **URL**: `/api/v1/auth/current-user`
- **方法**: `GET`
- **描述**: 获取用户信息，支持无登录状态访问。如果已登录则返回当前用户信息，如果未登录但提供userId参数则返回指定用户信息
- **权限**: 无需登录验证，公开接口

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| userId | Long | 否 | 用户ID（可选），如果不传且已登录则获取当前登录用户信息 |

#### 响应字段说明

| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | Long | 用户ID |
| username | String | 用户名 |
| nickname | String | 昵称 |
| email | String | 邮箱 |
| phone | String | 手机号 |
| avatar | String | 头像URL |
| status | String | 用户状态 |
| isVip | Boolean | 是否VIP |
| lastLoginTime | String | 最后登录时间 |
| loginCount | Integer | 登录次数 |
| createTime | String | 创建时间 |
| **isLogin** | **Boolean** | **是否为当前登录用户** |
| **followingCount** | **Long** | **关注数（用户关注的人数）** |
| **followersCount** | **Long** | **粉丝数（关注该用户的人数）** |
| **likeCount** | **Long** | **点赞数（用户发出的点赞总数）** |

#### 响应示例

**已登录用户访问（不带参数）：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 1,
    "username": "testuser",
    "nickname": "测试用户",
    "email": "test@example.com",
    "phone": "13800138000",
    "avatar": "https://example.com/avatar.jpg",
    "status": "active",
    "isVip": false,
    "isLogin": true,
    "lastLoginTime": "2024-01-27 10:30:00",
    "loginCount": 5,
    "createTime": "2024-01-01 00:00:00",
    "followingCount": 10,
    "followersCount": 25,
    "likeCount": 150
  },
  "success": true,
  "timestamp": 1703123456789
}
```

**未登录用户访问（不带参数）：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "isLogin": false,
    "message": "用户未登录"
  },
  "success": true,
  "timestamp": 1703123456789
}
```

**指定用户ID访问：**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 2,
    "username": "otheruser",
    "nickname": "其他用户",
    "email": "other@example.com",
    "phone": "13900139000",
    "avatar": "https://example.com/avatar2.jpg",
    "status": "active",
    "isVip": true,
    "isLogin": false,
    "lastLoginTime": "2024-01-26 15:20:00",
    "loginCount": 8,
    "createTime": "2024-01-01 00:00:00",
    "followingCount": 5,
    "followersCount": 12,
    "likeCount": 89
  },
  "success": true,
  "timestamp": 1703123456789
}
```

### 4. 校验token

- **URL**: `/api/v1/auth/check-token`
- **方法**: `GET`
- **描述**: 校验当前token是否有效

#### 响应示例

```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "valid": true,
    "userId": 1,
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expiresIn": 2592000
  },
  "success": true,
  "timestamp": 1703123456789
}
```

### 5. 刷新token

- **URL**: `/api/v1/auth/refresh-token`
- **方法**: `POST`
- **描述**: 刷新当前token

#### 响应示例

```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expiresIn": 2592000,
    "userId": 1
  },
  "success": true,
  "timestamp": 1703123456789
}
```

## 更新日志

### v2.0.0 (2024-01-27)
- **新增**: 在 `current-user` 接口中添加了用户统计信息
  - `followingCount`: 关注数（用户关注的人数）
  - `followersCount`: 粉丝数（关注该用户的人数）
  - `likeCount`: 点赞数（用户发出的点赞总数）
- **优化**: 添加了异常处理，确保统计信息获取失败时不影响主要功能
- **依赖**: 新增对 `FollowService` 和 `LikeService` 的依赖

## 注意事项

1. **统计信息获取**: 新增的统计字段通过调用相应的服务获取，如果服务调用失败会设置默认值0
2. **性能考虑**: 统计信息是实时计算的，对于高频调用可能需要考虑缓存优化
3. **向后兼容**: 新增字段不影响现有功能，保持向后兼容
4. **错误处理**: 统计信息获取失败不会影响用户基本信息的返回

## 技术实现

### 依赖服务
- `UserService`: 用户基本信息
- `FollowService`: 关注相关统计
- `LikeService`: 点赞相关统计

### 关键方法
```java
private Map<String, Object> buildUserInfo(User user) {
    // 基础用户信息
    // ...
    
    // 统计信息
    Long followingCount = followService.getFollowingCount(user.getId());
    Long followersCount = followService.getFollowersCount(user.getId());
    Long likeCount = likeService.countUserLikes(user.getId(), null);
    
    // 异常处理和默认值设置
}
```
