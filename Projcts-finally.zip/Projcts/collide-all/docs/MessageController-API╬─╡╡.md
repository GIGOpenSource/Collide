# 消息管理API接口文档

## 基本信息
- **控制器名称**: MessageController
- **基础路径**: `/api/v1/messages`
- **描述**: 消息相关的API接口，支持私信、留言板、消息回复等功能

## 接口列表

### 1. 消息列表查询

#### 接口信息
- **请求方式**: GET
- **接口路径**: `/api/v1/messages/list`
- **接口描述**: 支持按发送者、接收者、类型等条件查询消息列表。将相同发送者和接收者之间的多个消息合并，只返回每个对话的最新一条消息，实现聊天会话列表功能

#### 请求参数

| 参数名 | 类型 | 必填 | 默认值 | 描述 |
|--------|------|------|--------|------|
| senderId | Long | 否 | - | 发送者ID |
| receiverId | Long | 否 | - | 接收者ID |
| messageType | String | 否 | - | 消息类型 |
| status | String | 否 | - | 消息状态 |
| isRead | Boolean | 否 | - | 是否已读 |
| keyword | String | 否 | - | 关键词搜索 |
| orderBy | String | 否 | createTime | 排序字段 |
| orderDirection | String | 否 | DESC | 排序方向 |
| currentPage | Integer | 否 | 1 | 当前页码 |
| pageSize | Integer | 否 | 20 | 页面大小 |

#### 请求示例
```http
GET /api/v1/messages/list?senderId=1&receiverId=2&messageType=PRIVATE&currentPage=1&pageSize=10
```

#### 响应参数

```json
{
  "code": 200,
  "message": "success",
  "data": {
    "records": [
      {
        "id": 1,
        "senderId": 1,
        "senderNickname": "发送者昵称",
        "senderAvatar": "https://example.com/avatar1.jpg",
        "receiverId": 2,
        "receiverNickname": "接收者昵称",
        "receiverAvatar": "https://example.com/avatar2.jpg",
        "messageType": "PRIVATE",
        "content": "消息内容",
        "status": "ACTIVE",
        "isRead": false,
        "parentMessageId": null,
        "createTime": "2024-01-01T00:00:00",
        "updateTime": "2024-01-01T00:00:00"
      },
      {
        "id": 2,
        "senderId": 2,
        "senderNickname": "接收者昵称",
        "senderAvatar": "https://example.com/avatar2.jpg",
        "receiverId": 1,
        "receiverNickname": "发送者昵称",
        "receiverAvatar": "https://example.com/avatar1.jpg",
        "messageType": "PRIVATE",
        "content": "回复消息内容",
        "status": "ACTIVE",
        "isRead": false,
        "parentMessageId": null,
        "createTime": "2024-01-01T01:00:00",
        "updateTime": "2024-01-01T01:00:00"
      }
    ],
    "total": 120,
    "currentPage": 1,
    "pageSize": 10,
    "totalPages": 12
  }
}
```

#### 响应说明
- **records**: 消息记录数组，相同发送者和接收者之间的消息会被合并为一个连续的对话数组
- **对话合并逻辑**: 
  - 将相同发送者和接收者之间的消息按时间正序排列（最新的消息在最后）
  - 不同对话组之间按最新消息时间倒序排列（最新的对话在前）
  - 支持双向对话：A发送给B的消息和B发送给A的消息会被合并为同一个对话

### 2. 查询t_message表数据

#### 接口信息
- **请求方式**: GET
- **接口路径**: `/api/v1/messages/query`
- **接口描述**: 查询t_message表中的消息数据，提供基础的消息查询功能。如果发送人和同一个接收人有多条消息，将消息合并并且倒序排序返回给前端

#### 请求参数

| 参数名 | 类型 | 必填 | 默认值 | 描述 |
|--------|------|------|--------|------|
| id | Long | 否 | - | 消息ID |
| senderId | Long | 否 | - | 发送者ID |
| receiverId | Long | 否 | - | 接收者ID |
| messageType | String | 否 | - | 消息类型 |
| status | String | 否 | - | 消息状态 |
| startTime | String | 否 | - | 开始时间（格式：yyyy-MM-dd HH:mm:ss） |
| endTime | String | 否 | - | 结束时间（格式：yyyy-MM-dd HH:mm:ss） |
| currentPage | Integer | 否 | 1 | 当前页码 |
| pageSize | Integer | 否 | 20 | 页面大小 |

#### 请求示例
```http
GET /api/v1/messages/query?senderId=1&messageType=text&startTime=2024-01-01 00:00:00&endTime=2024-12-31 23:59:59&currentPage=1&pageSize=20
```

#### 响应参数

```json
{
  "code": 200,
  "message": "success",
  "data": [
    {
      "id": 1,
      "senderId": 1,
      "receiverId": 2,
      "content": "消息内容",
      "messageType": "text",
      "extraData": {
        "fileUrl": "https://example.com/file.jpg",
        "fileSize": 1024
      },
      "status": "sent",
      "readTime": "2024-01-01T10:30:00",
      "replyToId": null,
      "isPinned": false,
      "createTime": "2024-01-01T10:00:00",
      "updateTime": "2024-01-01T10:00:00"
    }
  ]
}
```

### 3. 写入t_message表数据

#### 接口信息
- **请求方式**: POST
- **接口路径**: `/api/v1/messages/write`
- **接口描述**: 向t_message表中写入消息数据，提供基础的消息写入功能

#### 请求参数

**请求体**: MessageCreateRequest

| 参数名 | 类型 | 必填 | 默认值 | 描述 |
|--------|------|------|--------|------|
| senderId | Long | 是 | - | 发送者ID |
| receiverId | Long | 是 | - | 接收者ID |
| content | String | 是 | - | 消息内容 |
| messageType | String | 是 | text | 消息类型 |
| extraData | Object | 否 | - | 扩展数据（图片URL、文件信息等） |
| replyToId | Long | 否 | - | 回复的消息ID |
| isPinned | Boolean | 否 | false | 是否置顶 |

#### 请求示例
```http
POST /api/v1/messages/write
Content-Type: application/json

{
  "senderId": 1,
  "receiverId": 2,
  "content": "这是一条测试消息",
  "messageType": "text",
  "extraData": {
    "fileUrl": "https://example.com/file.jpg",
    "fileSize": 1024
  },
  "replyToId": null,
  "isPinned": false
}
```

#### 响应参数

```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 123,
    "senderId": 1,
    "receiverId": 2,
    "content": "这是一条测试消息",
    "messageType": "text",
    "extraData": {
      "fileUrl": "https://example.com/file.jpg",
      "fileSize": 1024
    },
    "status": "sent",
    "readTime": null,
    "replyToId": null,
    "isPinned": false,
    "createTime": "2024-01-01T10:00:00",
    "updateTime": "2024-01-01T10:00:00"
  }
}
```

## 响应字段说明

| 字段名 | 类型 | 描述 |
|--------|------|------|
| code | Integer | 响应状态码 |
| message | String | 响应消息 |
| data | Object/Array | 响应数据 |

### 分页响应字段说明

| 字段名 | 类型 | 描述 |
|--------|------|------|
| records | Array | 消息记录列表 |
| total | Integer | 总记录数 |
| currentPage | Integer | 当前页码 |
| pageSize | Integer | 页面大小 |
| totalPages | Integer | 总页数 |

## 消息记录字段说明

| 字段名 | 类型 | 描述 |
|--------|------|------|
| id | Long | 消息ID |
| senderId | Long | 发送者ID |
| senderNickname | String | 发送者昵称 |
| senderAvatar | String | 发送者头像 |
| receiverId | Long | 接收者ID |
| receiverNickname | String | 接收者昵称 |
| receiverAvatar | String | 接收者头像 |
| messageType | String | 消息类型 |
| content | String | 消息内容 |
| extraData | Object | 扩展数据 |
| status | String | 消息状态 |
| readTime | String | 已读时间 |
| replyToId | Long | 回复的消息ID |
| isPinned | Boolean | 是否置顶 |
| createTime | String | 创建时间 |
| updateTime | String | 更新时间 |

## 消息类型说明

| 类型值 | 描述 | 最大内容长度 |
|--------|------|-------------|
| text | 文本消息 | 1000字符 |
| image | 图片消息 | 200字符 |
| file | 文件消息 | 200字符 |
| system | 系统消息 | 500字符 |

## 消息状态说明

| 状态值 | 描述 |
|--------|------|
| sent | 已发送 |
| delivered | 已送达 |
| read | 已读 |
| deleted | 已删除 |

## 错误码说明

| 错误码 | 描述 |
|--------|------|
| 200 | 成功 |
| 400 | 请求参数错误 |
| 401 | 未授权 |
| 403 | 禁止访问 |
| 404 | 资源不存在 |
| 500 | 服务器内部错误 |

## 注意事项

1. 所有时间字段格式为ISO 8601标准格式
2. 分页参数currentPage从1开始
3. pageSize建议不超过100
4. 排序方向支持ASC（升序）和DESC（降序）
5. 消息类型包括：text（文本）、image（图片）、file（文件）、system（系统）
6. 消息状态包括：sent（已发送）、delivered（已送达）、read（已读）、deleted（已删除）
7. 排序字段支持：createTime（创建时间）、updateTime（更新时间）
8. 通过MessageFacadeService可以调用更多消息相关功能
9. 新增的query接口使用MyBatis-Plus的QueryWrapper动态构建查询条件
10. 新增的write接口支持完整的消息创建流程，包含参数验证和业务逻辑
